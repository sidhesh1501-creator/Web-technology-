# PowerShell script to deploy Student Result App to Apache Tomcat
$TomcatPath = "C:\Users\Sadhanandhan\OneDrive\Desktop\Mine Files\WEB TWCH SOFTWARE\apache-tomcat-7.0.109"
$AppPath = "$TomcatPath\webapps\StudentResultApp"

Write-Host "1. Compiling ResultServlet.java..." -ForegroundColor Cyan
javac -cp "$TomcatPath\lib\servlet-api.jar" ResultServlet.java

if ($LASTEXITCODE -ne 0) {
    Write-Host "Compilation failed!" -ForegroundColor Red
    exit 1
}

Write-Host "2. Preparing web app directory structure at $AppPath..." -ForegroundColor Cyan
New-Item -ItemType Directory -Force -Path "$AppPath\WEB-INF\classes" | Out-Null

Write-Host "3. Copying web artifacts..." -ForegroundColor Cyan
Copy-Item "index.html" "$AppPath\" -Force
Copy-Item "style.css" "$AppPath\" -Force
Copy-Item "web.xml" "$AppPath\WEB-INF\" -Force
Copy-Item "ResultServlet.class" "$AppPath\WEB-INF\classes\" -Force

Write-Host "Deploy completed successfully!" -ForegroundColor Green
Write-Host "Access URL: http://localhost:8080/StudentResultApp/" -ForegroundColor Yellow
