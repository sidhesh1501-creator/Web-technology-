import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * ResultServlet
 * --------------
 * Accepts a student's Name, Register Number, and marks for three subjects
 * (submitted via POST from index.html), validates the input, computes
 * Total / Average / Highest / Pass-Fail, and writes the result page
 * directly to the response using PrintWriter.
 */
public class ResultServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    /** Minimum mark (out of 100) required in a subject to be considered a pass. */
    private static final int PASS_MARK = 35;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // ---- 1. Read parameters (all local variables — request-scoped) ----
        String studentName = request.getParameter("studentName");
        String regNumber   = request.getParameter("regNumber");
        String mark1Raw     = request.getParameter("mark1");
        String mark2Raw     = request.getParameter("mark2");
        String mark3Raw     = request.getParameter("mark3");

        List<String> errors = new ArrayList<String>();

        // ---- 2. Validate presence of text fields ----
        if (isBlank(studentName)) {
            errors.add("Student Name is required.");
        }
        if (isBlank(regNumber)) {
            errors.add("Register Number is required.");
        }

        // ---- 3. Validate each mark: present, numeric, and within 0-100 ----
        Integer mark1 = validateMark(mark1Raw, "Subject 1", errors);
        Integer mark2 = validateMark(mark2Raw, "Subject 2", errors);
        Integer mark3 = validateMark(mark3Raw, "Subject 3", errors);

        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        // ---- 4. If validation failed, render the error page ----
        if (!errors.isEmpty()) {
            writeErrorPage(out, errors);
            return;
        }

        // ---- 5. Perform calculations using local variables ----
        int total   = mark1 + mark2 + mark3;
        double average = total / 3.0;
        int highest = Math.max(mark1, Math.max(mark2, mark3));
        boolean pass = (mark1 >= PASS_MARK) && (mark2 >= PASS_MARK) && (mark3 >= PASS_MARK);

        writeResultPage(out, studentName, regNumber, mark1, mark2, mark3,
                total, average, highest, pass);
    }

    private Integer validateMark(String raw, String label, List<String> errors) {
        if (isBlank(raw)) {
            errors.add(label + " mark is required.");
            return null;
        }
        int value;
        try {
            value = Integer.parseInt(raw.trim());
        } catch (NumberFormatException e) {
            errors.add(label + " mark must be a valid whole number.");
            return null;
        }
        if (value < 0 || value > 100) {
            errors.add(label + " mark must be between 0 and 100 (got " + value + ").");
            return null;
        }
        return value;
    }

    private boolean isBlank(String s) {
        return s == null || s.trim().isEmpty();
    }

    /** Writes the validation-error page styled with dark glassmorphism. */
    private void writeErrorPage(PrintWriter out, List<String> errors) {
        out.println("<!DOCTYPE html>");
        out.println("<html lang='en'><head><meta charset='UTF-8'>");
        out.println("<meta name='viewport' content='width=device-width, initial-scale=1.0'>");
        out.println("<title>Result Processing - Validation Error</title>");
        out.println("<link rel='stylesheet' href='style.css'></head><body>");
        out.println("<div class='page-wrap'>");
        out.println("<header class='app-header'>");
        out.println("<div class='badge-tag' style='background:rgba(239,68,68,0.15); border-color:rgba(239,68,68,0.3); color:#fca5a5;'>Validation Exception</div>");
        out.println("<h1>Submission Could Not Be Processed</h1>");
        out.println("<p class='subtitle'>The server encountered validation errors with your submitted data.</p>");
        out.println("</header>");
        out.println("<main class='single-col'>");
        out.println("<div class='result-card-outer'>");
        out.println("<div class='error-box'>");
        out.println("<div class='error-title'><svg width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2'><circle cx='12' cy='12' r='10'/><line x1='12' y1='8' x2='12' y2='12'/><line x1='12' y1='16' x2='12.01' y2='16'/></svg> Please correct the following issues:</div>");
        out.println("<ul class='error-list'>");
        for (String message : errors) {
            out.println("<li>" + escape(message) + "</li>");
        }
        out.println("</ul></div>");
        out.println("<a class='back-link' href='index.html'><svg width='18' height='18' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2'><line x1='19' y1='12' x2='5' y2='12'/><polyline points='12 19 5 12 12 5'/></svg> Back to Marks Entry Form</a>");
        out.println("</div></main>");
        out.println("<footer class='app-footer'>Java Servlet Architecture &middot; Thread-Safe Validation &middot; Department of Examinations</footer>");
        out.println("</div></body></html>");
    }

    /** Writes the successful result page styled with dark glassmorphism. */
    private void writeResultPage(PrintWriter out, String name, String regNo,
            int m1, int m2, int m3, int total, double average, int highest, boolean pass) {

        String grade;
        if (!pass) {
            grade = "Re-appear Required";
        } else if (average >= 75) {
            grade = "First Class with Distinction";
        } else if (average >= 60) {
            grade = "First Class";
        } else if (average >= 50) {
            grade = "Second Class";
        } else {
            grade = "Pass Class";
        }

        out.println("<!DOCTYPE html>");
        out.println("<html lang='en'><head><meta charset='UTF-8'>");
        out.println("<meta name='viewport' content='width=device-width, initial-scale=1.0'>");
        out.println("<title>Official Result - " + escape(name) + "</title>");
        out.println("<link rel='stylesheet' href='style.css'></head><body>");
        out.println("<div class='page-wrap'>");
        out.println("<header class='app-header'>");
        out.println("<div class='badge-tag'>Official Academic Report</div>");
        out.println("<h1>Generated Result Summary</h1>");
        out.println("<p class='subtitle'>Calculated server-side by ResultServlet.doPost() from submitted form data</p>");
        out.println("</header>");
        out.println("<main class='single-col'>");
        out.println("<div class='result-card-outer'>");

        // Status Banner
        if (pass) {
            out.println("<div class='status-banner pass'>");
            out.println("<div class='status-info'>");
            out.println("<div class='status-icon-wrap'><svg width='28' height='28' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='3'><polyline points='20 6 9 17 4 12'/></svg></div>");
            out.println("<div><div class='status-title'>PASSED EXAMINATION</div><div class='status-sub'>Cleared all 3 subjects with minimum threshold (&ge; 35)</div></div>");
            out.println("</div><div class='status-badge-lg'>PASS</div></div>");
        } else {
            out.println("<div class='status-banner fail'>");
            out.println("<div class='status-info'>");
            out.println("<div class='status-icon-wrap'><svg width='28' height='28' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='3'><line x1='18' y1='6' x2='6' y2='18'/><line x1='6' y1='6' x2='18' y2='18'/></svg></div>");
            out.println("<div><div class='status-title'>RESULT: FAIL</div><div class='status-sub'>Failed one or more subjects (score below pass mark of 35)</div></div>");
            out.println("</div><div class='status-badge-lg'>FAIL</div></div>");
        }

        // Student Info
        out.println("<div class='student-info-bar'>");
        out.println("<div class='info-item'><span class='info-label'>Student Name</span><span class='info-value'>" + escape(name) + "</span></div>");
        out.println("<div class='info-item' style='text-align:right;'><span class='info-label'>Register Number</span><span class='info-value'>" + escape(regNo) + "</span></div>");
        out.println("</div>");

        // Metrics Grid
        out.println("<div class='metrics-grid'>");
        out.println("<div class='metric-card total'><div class='metric-label'>Grand Total</div><div class='metric-val'>" + total + "</div><div class='metric-sub'>Out of 300</div></div>");
        out.println("<div class='metric-card average'><div class='metric-label'>Average</div><div class='metric-val'>" + String.format("%.2f", average) + "%</div><div class='metric-sub'>" + grade + "</div></div>");
        out.println("<div class='metric-card highest'><div class='metric-label'>Highest Mark</div><div class='metric-val'>" + highest + "</div><div class='metric-sub'>Out of 100</div></div>");
        out.println("</div>");

        // Subject Table
        out.println("<div class='subject-table-wrap'>");
        out.println("<table class='subject-table'><thead><tr><th>Subject</th><th>Max Marks</th><th>Marks Obtained</th><th>Status</th></tr></thead><tbody>");
        out.println("<tr><td>Subject 1</td><td>100</td><td><strong>" + m1 + "</strong></td><td>" + (m1 >= PASS_MARK ? "<span class='pill-sm pass'>PASS</span>" : "<span class='pill-sm fail'>FAIL (&lt;35)</span>") + "</td></tr>");
        out.println("<tr><td>Subject 2</td><td>100</td><td><strong>" + m2 + "</strong></td><td>" + (m2 >= PASS_MARK ? "<span class='pill-sm pass'>PASS</span>" : "<span class='pill-sm fail'>FAIL (&lt;35)</span>") + "</td></tr>");
        out.println("<tr><td>Subject 3</td><td>100</td><td><strong>" + m3 + "</strong></td><td>" + (m3 >= PASS_MARK ? "<span class='pill-sm pass'>PASS</span>" : "<span class='pill-sm fail'>FAIL (&lt;35)</span>") + "</td></tr>");
        out.println("</tbody></table></div>");

        // Actions
        out.println("<div class='action-row'>");
        out.println("<a class='back-link' href='index.html'><svg width='18' height='18' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2'><line x1='19' y1='12' x2='5' y2='12'/><polyline points='12 19 5 12 12 5'/></svg> Submit Another Student</a>");
        out.println("<button onclick='window.print()' class='btn btn-secondary' style='flex:0 0 auto; padding:10px 18px;'><svg width='16' height='16' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2'><polyline points='6 9 6 2 18 2 18 9'/><path d='M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2'/><rect x='6' y='14' width='12' height='8'/></svg> Print Report</button>");
        out.println("</div>");

        out.println("</div></main>");
        out.println("<footer class='app-footer'>Java Servlet Architecture &middot; Thread-Safe Local Request Scope &middot; Department of Examinations</footer>");
        out.println("</div></body></html>");
    }

    private String escape(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;");
    }
}
