const http = require('http');
const fs = require('fs');
const path = require('path');
const querystring = require('querystring');

const PORT = 3000;
const PASS_MARK = 35;

function escapeHtml(s) {
  if (!s) return "";
  return String(s)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

const server = http.createServer((req, res) => {
  if (req.method === 'GET') {
    let filePath = req.url === '/' ? '/index.html' : req.url;
    filePath = path.join(__dirname, filePath);

    const extname = path.extname(filePath);
    let contentType = 'text/html';
    if (extname === '.css') contentType = 'text/css';
    if (extname === '.js') contentType = 'text/javascript';
    if (extname === '.png') contentType = 'image/png';

    fs.readFile(filePath, (err, content) => {
      if (err) {
        res.writeHead(404, { 'Content-Type': 'text/html' });
        res.end('<h1>404 Not Found</h1>');
      } else {
        res.writeHead(200, { 'Content-Type': contentType });
        res.end(content, 'utf-8');
      }
    });
  } else if (req.method === 'POST' && (req.url === '/ResultServlet' || req.url === 'ResultServlet')) {
    let body = '';
    req.on('data', chunk => {
      body += chunk.toString();
    });

    req.on('end', () => {
      const params = querystring.parse(body);
      const studentName = params.studentName;
      const regNumber = params.regNumber;
      const mark1Raw = params.mark1;
      const mark2Raw = params.mark2;
      const mark3Raw = params.mark3;

      const errors = [];

      if (!studentName || !studentName.trim()) {
        errors.push("Student Name is required.");
      }
      if (!regNumber || !regNumber.trim()) {
        errors.push("Register Number is required.");
      }

      function validateMark(raw, label) {
        if (!raw || !raw.trim()) {
          errors.push(label + " mark is required.");
          return null;
        }
        const val = Number(raw.trim());
        if (isNaN(val) || !Number.isInteger(val)) {
          errors.push(label + " mark must be a valid whole number.");
          return null;
        }
        if (val < 0 || val > 100) {
          errors.push(label + " mark must be between 0 and 100 (got " + val + ").");
          return null;
        }
        return val;
      }

      const mark1 = validateMark(mark1Raw, "Subject 1");
      const mark2 = validateMark(mark2Raw, "Subject 2");
      const mark3 = validateMark(mark3Raw, "Subject 3");

      res.writeHead(200, { 'Content-Type': 'text/html; charset=UTF-8' });

      if (errors.length > 0) {
        // Render Error Page
        let errorHtml = `<!DOCTYPE html>
<html lang="en"><head><meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Result Processing - Validation Error</title>
<link rel="stylesheet" href="style.css"></head><body>
<div class="page-wrap">
<header class="app-header">
<div class="badge-tag" style="background:rgba(239,68,68,0.15); border-color:rgba(239,68,68,0.3); color:#fca5a5;">Validation Exception</div>
<h1>Submission Could Not Be Processed</h1>
<p class="subtitle">The server encountered validation errors with your submitted data.</p>
</header>
<main class="single-col">
<div class="result-card-outer">
<div class="error-box">
<div class="error-title"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg> Please correct the following issues:</div>
<ul class="error-list">`;
        errors.forEach(msg => {
          errorHtml += `<li>${escapeHtml(msg)}</li>`;
        });
        errorHtml += `</ul></div>
<a class="back-link" href="index.html"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/></svg> Back to Marks Entry Form</a>
</div></main>
<footer class="app-footer">Java Servlet Architecture &middot; Thread-Safe Validation &middot; Department of Examinations</footer>
</div></body></html>`;
        res.end(errorHtml);
        return;
      }

      // Perform calculations
      const total = mark1 + mark2 + mark3;
      const average = total / 3.0;
      const highest = Math.max(mark1, mark2, mark3);
      const pass = (mark1 >= PASS_MARK) && (mark2 >= PASS_MARK) && (mark3 >= PASS_MARK);

      let grade = "Re-appear Required";
      if (pass) {
        if (average >= 75) grade = "First Class with Distinction";
        else if (average >= 60) grade = "First Class";
        else if (average >= 50) grade = "Second Class";
        else grade = "Pass Class";
      }

      let resultHtml = `<!DOCTYPE html>
<html lang="en"><head><meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Official Result - ${escapeHtml(studentName)}</title>
<link rel="stylesheet" href="style.css"></head><body>
<div class="page-wrap">
<header class="app-header">
<div class="badge-tag">Official Academic Report</div>
<h1>Generated Result Summary</h1>
<p class="subtitle">Calculated server-side by ResultServlet.doPost() from submitted form data</p>
</header>
<main class="single-col">
<div class="result-card-outer">`;

      if (pass) {
        resultHtml += `<div class="status-banner pass">
<div class="status-info">
<div class="status-icon-wrap"><svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="20 6 9 17 4 12"/></svg></div>
<div><div class="status-title">PASSED EXAMINATION</div><div class="status-sub">Cleared all 3 subjects with minimum threshold (&ge; 35)</div></div>
</div><div class="status-badge-lg">PASS</div></div>`;
      } else {
        resultHtml += `<div class="status-banner fail">
<div class="status-info">
<div class="status-icon-wrap"><svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></div>
<div><div class="status-title">RESULT: FAIL</div><div class="status-sub">Failed one or more subjects (score below pass mark of 35)</div></div>
</div><div class="status-badge-lg">FAIL</div></div>`;
      }

      resultHtml += `<div class="student-info-bar">
<div class="info-item"><span class="info-label">Student Name</span><span class="info-value">${escapeHtml(studentName)}</span></div>
<div class="info-item" style="text-align:right;"><span class="info-label">Register Number</span><span class="info-value">${escapeHtml(regNumber)}</span></div>
</div>

<div class="metrics-grid">
<div class="metric-card total"><div class="metric-label">Grand Total</div><div class="metric-val">${total}</div><div class="metric-sub">Out of 300</div></div>
<div class="metric-card average"><div class="metric-label">Average</div><div class="metric-val">${average.toFixed(2)}%</div><div class="metric-sub">${grade}</div></div>
<div class="metric-card highest"><div class="metric-label">Highest Mark</div><div class="metric-val">${highest}</div><div class="metric-sub">Out of 100</div></div>
</div>

<div class="subject-table-wrap">
<table class="subject-table"><thead><tr><th>Subject</th><th>Max Marks</th><th>Marks Obtained</th><th>Status</th></tr></thead><tbody>
<tr><td>Subject 1</td><td>100</td><td><strong>${mark1}</strong></td><td>${mark1 >= PASS_MARK ? "<span class='pill-sm pass'>PASS</span>" : "<span class='pill-sm fail'>FAIL (&lt;35)</span>"}</td></tr>
<tr><td>Subject 2</td><td>100</td><td><strong>${mark2}</strong></td><td>${mark2 >= PASS_MARK ? "<span class='pill-sm pass'>PASS</span>" : "<span class='pill-sm fail'>FAIL (&lt;35)</span>"}</td></tr>
<tr><td>Subject 3</td><td>100</td><td><strong>${mark3}</strong></td><td>${mark3 >= PASS_MARK ? "<span class='pill-sm pass'>PASS</span>" : "<span class='pill-sm fail'>FAIL (&lt;35)</span>"}</td></tr>
</tbody></table></div>

<div class="action-row">
<a class="back-link" href="index.html"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/></svg> Submit Another Student</a>
<button onclick="window.print()" class="btn btn-secondary" style="flex:0 0 auto; padding:10px 18px;"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg> Print Report</button>
</div>

</div></main>
<footer class="app-footer">Java Servlet Architecture &middot; Thread-Safe Local Request Scope &middot; Department of Examinations</footer>
</div></body></html>`;

      res.end(resultHtml);
    });
  }
});

server.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
